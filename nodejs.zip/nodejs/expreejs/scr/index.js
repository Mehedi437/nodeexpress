const express = require ("express");
// const app = express();
// app.get("/",(req, res) => {
// res.send("hello from the express welcome")

// })
// app.get("/about",(req, res) => {
// res.status(200).send("hello from the About welcome")

// })

// app.listen(8000, () => {
// console.log("hello world ");
// })




