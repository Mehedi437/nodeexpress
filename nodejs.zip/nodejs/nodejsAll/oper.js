const add =(a, b) => {
return a +b;
}
const sub =(a, b) => {
return a - b;
}
const mult =(a, b) => {
return a * b;
}
const divided =(a, b) => {
return a  / b;
}
const remender =(a, b) => {
return a % b;
}

const name = "Mohammad mehedi"

module.exports ={add,name,sub,mult,divided,remender}