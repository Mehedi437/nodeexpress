// CLASS 05 MODULE
// const fs = require("fs");
// creating a new file
// fs.writeFileSync("read.txt","Welcome to Mohammad mehedi hassan")
// 1st data delete
// fs.writeFileSync("read.txt","welcome to, Mohammad mehedi hassan")

// how to add
// fs.appendFileSync("read.txt","  How are you ?")

// how to read 
// const buf_data = fs.readFileSync("read.txt");

// org_data =buf_data.toString()
// console.log(org_data);
// Node.js includes an additional data type called Buffer
// (not available in browser's javascript)
// buffer is mainly used to store binary data
// while read is form or  flile receving packts over the network

// CLASS 06
// Challenge time
// 1:Create a folder named it Thapa
// 2:Create a file in it named bio.txt and data into it
// 3:add more data into the flie  at the end of the existing data 
// 4:Read the data without getting the buffer data data at first
// 5:Rename the file name to mybio.txt
// 6:now delete both the file and the

// how to remove buffer data 
// const data = fs.readFileSync("read.txt","utf8");
// console.log(data);
// How to flile delete
// fs.unlinkSync("read.txt");


// CLASS 07

// const fs = require("fs");

// fs.writeFile("read.txt","Welcome to Mohammad mehedi",(err)=> {
//     console.log("files is created");
//     console.log(err);
// })



// CLASS 10

// const os = require("os");
// console.log(os.arch());
// console.log(os.hostname());
// console.log(os.platform());
// console.log(os.tmpdir());
// console.log(os.type());

// const freememory =os. freemem();
// console.log(`${freememory /1024 /1024 / 1024}`);

// CLASS 11
// const path = require('path');
// console.log(path.dirname('D:\nodejs\index.js'));
// console.log(path.extname('D:\nodejs\index.js'));
// console.log(path.basename('D:\nodejs\index.js'));
// console.log(path.parse('D:\nodejs\index.js'));


// CLASS 12
// const {add,name,sub,mult,remender,divided} = require('./oper');
// console.log(add(5,10));
// console.log(sub(50,10));
// console.log(mult(5,10));
// console.log(remender(5,10));
// console.log(divided(5,10));
// console.log(name);


// Class 13  NPM
// const chalk = require("chalk");
// const validator =require("validator")
// console.log(chalk.blue("hello world"));
// console.log(chalk.blue.underline.inverse("hello world"));
// console.log(chalk.blue.underline.inverse("hello world"));
// const res =validator.isEmail("mehedi@hassan.com")

// console.log(res ? chalk.green.inverse(res) : chalk.red.inverse(res));

// CLASS 15 HTTP
// const http = require("http");
// const server = http.createServer((req, res) => {
// res.end("Hello mohammad mehedi hassan")
// })
// server.listen(8000, "127.0.0.1", () => {
//     console.log("listening to the port to 8000");

// });


// CLASS 17 HTTP ROUTING

// const http = require("http");
// const server = http.createServer((req, res) => {
//     // console.log(req.url);
//     if (req.url == "/") {
//         res.end("Hello form the home page")
//     }else if(req.url == "/about") {
//         res.end("Hello form the about page")
//     }else if (req.url == "/contact"){
//         res.end("Hello form the contact page")
//     }
 
//     else{
//     res.writeHead(404,{"content-type" : "text/html"});
//     res.end("<h1>404 error pages . page doesn't ecist</h1>")
//     }
    
    

// })
// const http = require("http");






const http = require("http");
const fs = require("fs");
var requests = require("requests");
const homeFile = fs.readFile("home.html", "utf-8");
const server = http.createServer((req, res) => {
  if (req.url == "/") {
    requests(
      "http://api.openweathermap.org/data/2.5/weather?q=cox%27s%20bazar&appid=e46d273c1519f009e5e3f72aea80414c",
    
    )
      .on("data",  (chunk) => {
        console.log(chunk);
      })
      .on("end",  (err) => {
        if (err) return console.log("connection closed due to errors", err);

        console.log("end");
      });
  }
});

server.listen(8000, "127.0.0.1", () =>{
    console.log("listening to the port to 8000")
} )
       
























