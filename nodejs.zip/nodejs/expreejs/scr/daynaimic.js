const path = require("path");
const express = require ("express");
const app = express();

// console.log(path.join(__dirname,'../public'));
const staticpath = path.join(__dirname,'../public');
const templates = path.join(__dirname,'../templates');
// TO SET THE VIEW ENGIE
app.set("view engine", "hbs");
app.set('views', templates )
app.use(express.static(staticpath));
// template engine route
app.get("/", (req, res) => {
res.render("index");
});
app.get("/",(req, res) => {
res.send("hello from the express welcome")

})
app.get("/about",(req, res) => {
res.status(200).send("hello from the About welcome")

})

app.listen(8000, () => {
console.log("hello world ");
})

