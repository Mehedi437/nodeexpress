const http = require("http");
const fs = require("fs");

const server = http.createServer((req, res) => {
  const data = fs.readFileSync(`${__dirname}/UserApi/userapi.json`, "utf-8");
  const objData = JSON.parse(data);
  // console.log(req.url);
  if (req.url == "/") {
    res.end("Hello form the home page");
  } else if (req.url == "/userapi") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(objData[9].name);
  } else if (req.url == "/about") {
    res.end("Hello form the about page");
  } else if (req.url == "/contact") {
    res.end("Hello form the contact page");
  } else {
    res.writeHead(404, { "content-type": "text/html" });
    res.end("<h1>404 error pages . page doesn't ecist</h1>");
  }
});
server.listen(8000, "127.0.0.1", () => {
  console.log("listening to the port to 8000");
});
